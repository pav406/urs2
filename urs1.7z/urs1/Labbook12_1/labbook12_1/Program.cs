﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace labbook12_1
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader stream = null;
            Console.WriteLine("enter filename to read:");
            string fname = Console.ReadLine();
            try
            {
                stream = new StreamReader(fname + ".txt");
                Console.WriteLine("contents of a file:\n");
                string str = stream.ReadToEnd();
                Console.WriteLine(str);
                stream.Close();
            }

            catch (FileNotFoundException)
            {
                Console.WriteLine("file not exits");
            }
            Console.ReadLine();
        }
    }
}
